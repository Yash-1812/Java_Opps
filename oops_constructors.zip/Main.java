public class Main{
    public static void main(String args[]){
        Student s1 = new Student();
        Student s2 = new Student("Yash" , 19);
        s1.print_details();
        s2.print_details();
    }
}