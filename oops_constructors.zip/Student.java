// Constructor overloading
class Student{
    String name;
    int roll_no;
    Student(){
        name = "unknown";
        roll_no = 0;
    }
    Student(String name , int roll_no){
        this.name = name;
        this.roll_no = roll_no;
    }
    
    void print_details(){
        System.out.println("Student name is "+this.name+"\n"+"Student roll_no is "+this.roll_no);
    }
}